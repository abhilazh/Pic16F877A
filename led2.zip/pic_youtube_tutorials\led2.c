#include<pic.h>
#define __XTAL_FREQ 16000000;
